let mongoose=require('mongoose')
let schema=mongoose.Schema
let CakecatalogSchema=new schema({
    cimage:String,
    cname:String,
    cprice: Number,
    cid: Number

})
module.exports=mongoose.model("items",CakecatalogSchema)