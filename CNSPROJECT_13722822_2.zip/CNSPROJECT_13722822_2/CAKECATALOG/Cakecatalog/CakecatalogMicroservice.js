let express=require('express')
let appServer= express()
require('./db/Cakecatalogbd')
let CakecatalogRouter=require('./routes/CakecatalogRouter')
appServer.use("/Cakecatalog",CakecatalogRouter)


//http://localhost:7100/Cakecatalog/getCakecatalogDetails
//http://localhost:7100/Cakecatalog//getCaketypeusingname/:name
//http://localhost:7100/Cakecatalog/getCaketypeusingid/:id
//http://localhost:7100/Cakecatalog/getCaketypeusingprice/:minValue/:maxValue

appServer.listen(7100,()=>{
  console.log("the connection is succesful and it is 7100")
})