let CakecatalogModel=require('../model/CakecatalogModel')
exports.courseData =function(req,res){

    
    
CakecatalogModel.find()
.then((data)=>{
    res.send(data);
})
.catch((err)=>{
    res.send("Error while fetching the data. Please contact the admin")
    console.log("Error while executing find method ",err)
})
}

exports.specificCatalogData = function (req, res) {
    let selection = req.params.name;
    console.log(selection);
    CakecatalogModel
      .find({ name: selection })
      .then((data) => {
        res.send(data);
      })
      .catch((err) => {
        res.send("Error while fetching data");
        console.log("Error while executing find method", err);
      });
    }

    exports.specificdataonid = function (req, res) {
        let selectionid =(req.params.cakeid);
        console.log(selectionid);
        CakecatalogModel
          .find({ cid: selectionid},
                { projection: { name: 1, price: 1, image: 0, cakeid: 1 } },
                { projection: { _id: 0 } })
          .then((data) => {

            res.send(data);
          })
          .catch((err) => {
            res.send("Error while fetching data");
            console.log("Error while executing find method", err);
          });
        }

        exports.specificCakePrice = function (req, res) {
            let minValue = parseInt(req.params.minValue);
            let maxValue = parseInt(req.params.maxValue);
            CakecatalogModel
              .find(
                { price: { $gte: minValue, $lte: maxValue } },
                { projection: { name: 1, price: 1, image: -1, cakeid: 1 } },
                { projection: { _id: 0 } }
              )
              .then((data) => {
                res.send(data);
                console.log(data);
              })
              .catch((err) => {
                res.send("Error while fetching the data. Please contact admin");
                console.log("Error while executing find method", err);
              });
          };