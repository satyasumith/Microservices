var express = require('express');
var router = express.Router();
let CakecatalogController =require('../controller/CakecatalogController')


/* GET home page. */
router.get('/getCakecatalogDetails',CakecatalogController.courseData);
router.get('/getCaketypeusingname/:name',CakecatalogController.specificCatalogData);
router.get('/getCaketypeusingid/:id',CakecatalogController.specificdataonid);
router.get('/getCaketypeusingprice/:minValue/:maxValue',CakecatalogController.specificCakePrice);
module.exports = router;
