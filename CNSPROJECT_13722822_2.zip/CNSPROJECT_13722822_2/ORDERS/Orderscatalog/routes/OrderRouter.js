var express = require('express');
var router = express.Router();
let OrderController =require('../controller/OrderController')


/* GET home page. */
router.get('/getOrderDetails',OrderController.cakeData);
router.get('/getcartDetails',OrderController.cakecartdata);
router.get('/addOrderDetails/:name',OrderController.specificCatalogData);
router.get('/removeOrderDetails/:name',OrderController.removeitems);
router.get('/checkoutForOrders',OrderController.checkout);

module.exports = router;
