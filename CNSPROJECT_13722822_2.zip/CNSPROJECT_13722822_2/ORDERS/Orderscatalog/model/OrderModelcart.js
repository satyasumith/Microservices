let mongoose=require('mongoose')
let schema=mongoose.Schema
let OrderSchema=new schema({
    cimage:String,
    cname:String,
    cprice: Number,
    cid: Number

})
module.exports=mongoose.model("cartitems",OrderSchema)