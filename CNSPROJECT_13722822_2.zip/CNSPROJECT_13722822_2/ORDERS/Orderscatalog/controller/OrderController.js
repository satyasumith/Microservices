let OrderModel=require('../model/OrderModel')
let OrderModel1=require('../model/OrderModelcart')
exports.cakeData =function(req,res){
    
OrderModel.find()
.then((data)=>{
    res.send(data);
})
.catch((err)=>{
    res.send("Error while fetching the data. Please contact the admin")
    console.log("Error while executing find method ",err)
})
}

exports.specificCatalogData = function (req, res) {
    let selection = req.params.name;
    console.log(selection);
    OrderModel
      .find({ name: selection })
      .then((data) => {
       
        OrderModel1.collection.insertMany(data)
        res.send("item added sucessfully")
       // res.send(data);
      })
      .catch((err) => {
        res.send("Error while fetching data");
        console.log("Error while executing find method", err);
      });
    }
    exports.cakecartdata =function(req,res){
       
        OrderModel1.find()
        .then((data)=>{
            res.send(data);
        })
        .catch((err)=>{
            res.send("Error while fetching the data in the cart")
            console.log("Error while executing find method ",err)
        })
        }
     
        exports.removeitems =function(req,res){
            let selection = req.params.name;
            OrderModel1.find({ name: selection })
            .then((data)=>{
                
                OrderModel1.collection.deleteMany({ name: selection })
                res.send("the item is removed");
            })
            .catch((err)=>{
                res.send("you do not have the item in the cart")
                console.log("error during deletion ",err)
            })
            }
            exports.checkout =function(req,res){
                
                OrderModel1.find()

                .then((data)=>{
                  
                    res.send(data);
                })
                .catch((err)=>{
                    res.send("your cart is empty or you have an error")
                    console.log("error during deletion ",err)
                })
                }