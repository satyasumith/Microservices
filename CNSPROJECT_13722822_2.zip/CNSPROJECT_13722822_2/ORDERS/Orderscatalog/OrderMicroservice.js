let express=require('express')
let appServer1= express()
require('./db/Orderdb')
let OrderRouter=require('./routes/OrderRouter')
appServer1.use("/Orders",OrderRouter)


//http://localhost:7200/Orders/getOrderDetails
//http://localhost:7200/Orders/addOrderDetails/:name
//http://localhost:7200/Orders/getcartDetails
//http://localhost:7200/Orders/removeOrderDetails/:name
//http://localhost:7200/Orders/checkoutForOrders

appServer1.listen(7200,()=>{
  console.log("the connection is succesful and it is 7200")
})