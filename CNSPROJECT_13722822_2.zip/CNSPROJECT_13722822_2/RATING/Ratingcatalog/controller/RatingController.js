let ratingModel = require("../model/RatingModel");
let cartModel = require("../model/cartModel");

exports.cakeData =function(req,res){
    
  ratingModel.find()
  .then((data)=>{
      res.send(data);
  })
  .catch((err)=>{
      res.send("Error while fetching the data. Please contact the admin")
      console.log("Error while executing find method ",err)
  })
  }

exports.rateCake = function (req, res) {
  let cakeName = req.params.cName;
  let rating = req.params.cRating;
  let ratingDoc = { name: cakeName, rating: rating };
  ratingModel
    .find({ name: cakeName })
    .then((data) => {
      if (data != "") {
        console.log(data);
        if (rating < 0 || rating > 10) {
          res.send("Your rating must be between 0 to 10");
        } else {
          cartModel.insertMany(ratingDoc)
            .then((dat) => {
            console.log(ratingDoc)
          //  res.send(ratingDoc)
              res.send("Thank you your review is recorded");
            })
            .catch((inserterror) => {
              res.send("Error occured in insert method");
              console.log(inserterror);
            });
        }
      } else {
        //console.log(data);
        res.send("You cannot rate cakes you have not ordered");
      }
    })
    .catch((finderror) => {
      res.send("Error in find method");
      console.log(finderror);
    });
};
