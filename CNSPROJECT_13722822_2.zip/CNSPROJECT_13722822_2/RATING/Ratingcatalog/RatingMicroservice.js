let express=require('express')
let appServer3= express()
require('./db/Ratingdb')
let RatingRouter=require('./routes/RatingRouter')
appServer3.use("/RatingCake",RatingRouter)


//http://localhost:7300/RatingCake/getCakeinfoDetails
//http://localhost:7300/RatingCake//rateCake/:cName/:cRating


appServer3.listen(7300,()=>{
  console.log("the connection is succesful and it is 7300")
})