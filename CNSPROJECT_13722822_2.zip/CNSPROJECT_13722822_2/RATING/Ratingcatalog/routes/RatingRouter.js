var express = require('express');
var router = express.Router();
let RatingController =require('../controller/RatingController')


/* GET home page. */
router.get('/getCakeinfoDetails',RatingController.cakeData);
router.get("/rateCake/:cName/:cRating", RatingController.rateCake);

module.exports = router;
