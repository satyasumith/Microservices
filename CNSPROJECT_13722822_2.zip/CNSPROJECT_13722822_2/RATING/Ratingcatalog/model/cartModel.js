let mongoose = require("mongoose");
let schema = mongoose.Schema;
let ratingSchema = new schema({
  name: String,
  rating: Number,
  
});
module.exports = mongoose.model("rating", ratingSchema);
